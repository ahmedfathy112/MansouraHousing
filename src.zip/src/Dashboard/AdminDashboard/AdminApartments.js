import axios from "axios";
import { useEffect, useState } from "react";
import { FaHome, FaTrash, FaEdit, FaMoneyBillWave } from "react-icons/fa";
import Skeleton from "react-loading-skeleton";

const AdminApartments = () => {
  const [apartments, setApartments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data } = await axios.get("/api/Apartment/GetAll");
        setApartments(data);
      } catch (error) {
        console.error("Fetch error:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleDelete = async (apartmentId) => {
    if (!window.confirm("Delete this apartment?")) return;

    try {
      await axios.delete(`/api/Apartment/${apartmentId}`);
      setApartments(apartments.filter((a) => a.apartment_Id !== apartmentId));
    } catch (error) {
      console.error("Delete error:", error);
    }
  };

  return (
    <div className="p-4 md:p-6">
      <h1 className="text-2xl font-bold mb-6">All Apartments</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading
          ? Array(6)
              .fill()
              .map((_, i) => (
                <Skeleton key={i} height={150} className="rounded-xl" />
              ))
          : apartments.map((apartment) => (
              <div
                key={apartment.apartment_Id}
                className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-4"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-primary/10 p-2 rounded-lg">
                    <FaHome className="text-primary w-6 h-6" />
                  </div>
                  <h3 className="font-semibold">{apartment.title}</h3>
                </div>

                <div className="space-y-2 text-sm text-gray-600">
                  <p className="line-clamp-2">{apartment.description}</p>
                  <div className="flex items-center gap-2">
                    <FaMoneyBillWave className="text-gray-400" />
                    <span>{apartment.price} EGP</span>
                  </div>
                  <p className="text-sm">Address: {apartment.address}</p>
                </div>

                <div className="mt-4 flex justify-end gap-2">
                  <button
                    onClick={() => handleDelete(apartment.apartment_Id)}
                    className="flex items-center gap-2 text-red-600 hover:text-red-700"
                  >
                    <FaTrash className="w-4 h-4" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            ))}
      </div>
    </div>
  );
};

export default AdminApartments;
