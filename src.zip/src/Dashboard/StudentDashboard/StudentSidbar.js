import { FaTimes, FaUser, FaHeart, FaSignOutAlt } from "react-icons/fa";
import { useAuth } from "../../AuthCheck";

const StudentSidebar = ({
  activeTab,
  setActiveTab,
  isMobileOpen,
  setIsMobileOpen,
}) => {
  const { logout } = useAuth();
  return (
    <div
      className={`fixed md:sticky z-20 w-64 h-screen bg-dark text-white transition-transform duration-300
        top-0 left-0 md:translate-x-0 ${
          isMobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
    >
      <div className="p-4 border-b border-gray-700 flex justify-between items-center">
        <h2 className="text-xl font-bold">Student Dashboard</h2>
        <button
          onClick={() => setIsMobileOpen(false)}
          className="md:hidden text-gray-400 hover:text-white"
        >
          <FaTimes className="w-5 h-5" />
        </button>
      </div>

      <nav className="p-4 space-y-2 h-[calc(100vh-160px)] overflow-y-auto">
        <button
          onClick={() => {
            setActiveTab("profile");
            setIsMobileOpen(false);
          }}
          className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors
            ${activeTab === "profile" ? "bg-primary" : "hover:bg-gray-700"}`}
        >
          <FaUser className="w-5 h-5" />
          <span>My Profile</span>
        </button>

        <button
          onClick={() => {
            setActiveTab("favorites");
            setIsMobileOpen(false);
          }}
          className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors
            ${activeTab === "favorites" ? "bg-primary" : "hover:bg-gray-700"}`}
        >
          <FaHeart className="w-5 h-5" />
          <span>Favorites</span>
        </button>
      </nav>

      <div className="absolute bottom-0 w-full p-4 border-t border-gray-700 bg-dark">
        <button
          onClick={() => {
            logout();
          }}
          className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-700 transition-colors"
        >
          <FaSignOutAlt className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

export default StudentSidebar;
