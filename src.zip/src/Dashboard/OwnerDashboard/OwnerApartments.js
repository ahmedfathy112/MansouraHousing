import { useState, useEffect } from "react";
import { FaBed, FaEdit, FaTrash } from "react-icons/fa";
import { jwtDecode } from "jwt-decode";
import { Link } from "react-router-dom";
import { MdOutlineStairs } from "react-icons/md";
import { ClipLoader } from "react-spinners"; // استيراد سبنر تحميل

const OwnerApartments = () => {
  const [apartments, setApartments] = useState([]);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedApartment, setSelectedApartment] = useState(null);
  const [fetchingApartments, setFetchingApartments] = useState(true); // حالة التحميل لجلب الشقق

  // جلب OwnerId من التوكن
  const getOwnerIdFromToken = () => {
    const token = localStorage.getItem("token");
    if (token) {
      const decodedToken = jwtDecode(token);
      return decodedToken[
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"
      ];
    }
    return null;
  };

  // جلب الشقق الخاصة بالمالك
  const fetchOwnerApartments = async () => {
    const ownerId = getOwnerIdFromToken();
    console.log("Owner ID from token:", ownerId);

    if (ownerId) {
      try {
        const response = await fetch(`/api/Apartment/GetAll`);

        if (response.ok) {
          const data = await response.json();
          console.log("Fetched apartments:", data);

          const filteredApartments = data.filter(
            (apartment) => String(apartment.ownerId) === String(ownerId)
          );

          console.log("Filtered Apartments:", filteredApartments);
          setApartments(filteredApartments);
        } else {
          throw new Error("Failed to fetch apartments.");
        }
      } catch (error) {
        console.error("Error fetching apartments:", error);
      } finally {
        setFetchingApartments(false); // إيقاف التحميل بعد الانتهاء
      }
    }
  };

  // جلب الشقق عند تحميل المكون
  useEffect(() => {
    fetchOwnerApartments();
  }, []);

  // حذف شقة
  const handleDelete = async (id, event) => {
    if (event) {
      event.preventDefault();
    }

    if (window.confirm("Are you sure you want to delete this apartment?")) {
      try {
        const response = await fetch(`/api/Apartment/${id}`, {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });

        if (response.ok) {
          setApartments(apartments.filter((apt) => apt.id !== id));
        } else {
          throw new Error("Failed to delete apartment.");
        }
      } catch (error) {
        console.error("Error deleting apartment:", error);
      }
    }
  };

  // فتح نموذج التعديل
  const handleEdit = (apartment, event) => {
    if (event) {
      event.preventDefault();
    }

    // تعيين OwnerId من التوكن إذا كان غير موجود
    if (!apartment.OwnerId) {
      apartment.OwnerId = getOwnerIdFromToken();
    }

    // تعيين Apartment_Image إذا كان غير موجود
    if (!apartment.Apartment_Image) {
      apartment.Apartment_Image = apartment.apartment_Image; // أو قم بإضافته يدويًا
    }

    setSelectedApartment(apartment); // تعيين الشقة المحددة
    setEditModalOpen(true); // فتح النموذج
  };

  // حفظ التعديلات
  const handleSave = async (updatedApartment) => {
    try {
      const requestBody = {
        Apartment_Id: updatedApartment.apartment_Id, // تأكد من أن Apartment_Id متطابق مع الرابط
        Num_Bed: updatedApartment.num_Bed,
        Num_Room: updatedApartment.num_Room,
        FloorNum: updatedApartment.floorNum,
        Description: updatedApartment.description,
        Address: updatedApartment.address,
        Price: updatedApartment.price,
        Title: updatedApartment.title,
        OwnerId: updatedApartment.OwnerId,
        Apartment_Image: updatedApartment.Apartment_Image,
      };

      console.log("Request Body:", requestBody); // تحقق من البيانات المرسلة

      const response = await fetch(
        `/api/Apartment/${updatedApartment.apartment_Id}`, // تأكد من أن Apartment_Id متطابق مع الرابط
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
          body: JSON.stringify(requestBody),
        }
      );

      console.log("Response:", response); // تحقق من الاستجابة

      if (response.ok) {
        const text = await response.text(); // تحقق من النص أولاً
        console.log("Response Text:", text);

        if (text) {
          const updatedData = JSON.parse(text); // تحويل النص إلى JSON
          console.log("Updated Data from Server:", updatedData);

          setApartments((prevApartments) =>
            prevApartments.map((apt) =>
              apt.apartment_Id === updatedData.apartment_Id ? updatedData : apt
            )
          );
          setEditModalOpen(false);
        } else {
          // إذا كانت الاستجابة فارغة، أعد جلب البيانات
          await fetchOwnerApartments();
          setEditModalOpen(false);
        }
      } else {
        const errorText = await response.text(); // تحقق من نص الخطأ
        console.error("Server Error:", errorText);
        throw new Error(`Failed to update apartment: ${errorText}`);
      }
    } catch (error) {
      console.error("Error updating apartment:", error);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">My Apartments</h1>

      {fetchingApartments ? ( // عرض سبنر تحميل أثناء جلب الشقق
        <div className="flex justify-center">
          <ClipLoader size={50} color="#3b82f6" />
        </div>
      ) : apartments.length === 0 ? ( // عرض رسالة إذا لم يكن هناك شقق
        <p className="text-gray-500 text-center">No apartments found.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {apartments.map((apartment) => (
            <Link
              key={apartment.apartment_Id}
              to={`/details/${apartment.apartment_Id}/owner/${apartment.ownerId}`}
              className="last-added-card p-2 text-black m-4 rounded-lg shadow-md text-left flex flex-col max-xl:w-1/4 max-md:w-full"
            >
              <img
                loading="lazy"
                alt={apartment.title}
                src={`data:image/jpeg;base64,${apartment.apartment_Image}`}
                className="w-full h-48 object-cover rounded-md"
              />
              <span className="text-[24px] font-semibold">
                ${apartment.price}
              </span>
              <span className="text-[18px] font-semibold">
                {apartment.title}
              </span>
              <span className="text-[12px] text-gray-500">
                {apartment.address}
              </span>
              <span className="text-[10px] text-gray-500">
                {new Date(apartment.publisheddate).toLocaleDateString()}
              </span>
              <div className="w-full flex flex-row mt-3">
                <div className="flex flex-row mr-5">
                  <FaBed className="my-auto mr-1" />
                  <span className="text-[11px]">{apartment.num_Bed} Beds</span>
                </div>
                <div className="flex flex-row">
                  <MdOutlineStairs className="my-auto mr-1" />
                  <span className="text-[11px]">
                    Floor {apartment.floorNum}
                  </span>
                </div>
              </div>
              <div className="flex gap-2 mt-6 justify-around">
                <button
                  onClick={(e) => handleEdit(apartment, e)}
                  className="text-blue-600 hover:text-blue-800"
                >
                  <FaEdit className="w-5 h-5" />
                </button>
                <button
                  onClick={(e) => handleDelete(apartment.apartment_Id, e)}
                  className="text-red-600 hover:text-red-800"
                >
                  <FaTrash className="w-5 h-5" />
                </button>
              </div>
            </Link>
          ))}
        </div>
      )}

      {editModalOpen && (
        <EditApartmentModal
          apartment={selectedApartment}
          onClose={() => setEditModalOpen(false)}
          onSave={handleSave}
          getOwnerIdFromToken={getOwnerIdFromToken} // تمرير الدالة كـ prop
        />
      )}
    </div>
  );
};

// نموذج تعديل الشقة
const EditApartmentModal = ({
  apartment,
  onClose,
  onSave,
  getOwnerIdFromToken,
}) => {
  const [formData, setFormData] = useState({
    apartment_Id: apartment.apartment_Id,
    num_Bed: apartment.num_Bed,
    num_Room: apartment.num_Room,
    floorNum: apartment.floorNum,
    description: apartment.description,
    address: apartment.address,
    price: apartment.price,
    title: apartment.title,
    OwnerId: apartment.OwnerId || getOwnerIdFromToken(), // تعيين OwnerId إذا كان غير موجود
    Apartment_Image: apartment.Apartment_Image || apartment.apartment_Image,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  return (
    <div className="fixed inset-0 top-20 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md h-[70vh] overflow-y-scroll">
        <h2 className="text-xl font-bold mb-4">Edit Apartment</h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Title
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="mt-1 p-2 w-full border rounded-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Price
            </label>
            <input
              type="number"
              name="price"
              value={formData.price}
              onChange={handleChange}
              className="mt-1 p-2 w-full border rounded-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Address
            </label>
            <input
              type="text"
              name="address"
              value={formData.address}
              onChange={handleChange}
              className="mt-1 p-2 w-full border rounded-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Description
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              className="mt-1 p-2 w-full border rounded-lg"
              rows="3"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Number of Beds
            </label>
            <input
              type="number"
              name="num_Bed"
              value={formData.num_Bed}
              onChange={handleChange}
              className="mt-1 p-2 w-full border rounded-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Number of Rooms
            </label>
            <input
              type="number"
              name="num_Room"
              value={formData.num_Room}
              onChange={handleChange}
              className="mt-1 p-2 w-full border rounded-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Floor Number
            </label>
            <input
              type="number"
              name="floorNum"
              value={formData.floorNum}
              onChange={handleChange}
              className="mt-1 p-2 w-full border rounded-lg"
            />
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
          >
            Cancel
          </button>
          <button
            onClick={() => onSave(formData)}
            className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default OwnerApartments;
