import { createContext, useContext, useState, useEffect } from "react";
import { jwtDecode } from "jwt-decode";

// إنشاء Context
const AuthContext = createContext();

// AuthProvider Component
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState("");
  const [StudentId, setStudentId] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState(null);

  const fetchUserData = () => {
    const token = localStorage.getItem("token");

    if (!token) {
      setIsAuthenticated(false);
      setUserRole(null);
      setUser("");
      return;
    }

    try {
      const decoded = jwtDecode(token);
      const {
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name": userName,
        "http://schemas.microsoft.com/ws/2008/06/identity/claims/role": role,
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier":
          Student_id,
      } = decoded;

      if (role == "student" || role == "owner") {
        setUserRole(role);
        setIsAuthenticated(true);
        setUser(userName);
      } else {
        setIsAuthenticated(false);
        setUserRole(null);
        setUser("");
      }
      if (role == "student") {
        setStudentId(Student_id);
      }
    } catch (error) {
      console.error("Error decoding token:", error);
      setIsAuthenticated(false);
      setUserRole(null);
      setUser("");
    }
  };

  // دالة تسجيل الخروج
  const logout = () => {
    localStorage.removeItem("token");
    setIsAuthenticated(false);
    setUserRole(null);
    setUser("");
  };

  useEffect(() => {
    const handleStorageChange = (event) => {
      if (event.key === "token") {
        fetchUserData();
      }
    };

    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  useEffect(() => {
    fetchUserData();
  }, []);

  const contextValue = {
    user,
    isAuthenticated,
    isOwner: userRole === "owner",
    isStudent: userRole === "student",
    fetchUserData,
    logout,
    StudentId,
  };

  return (
    <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
